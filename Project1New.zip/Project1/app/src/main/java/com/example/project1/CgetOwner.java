package com.example.project1;



public class CgetOwner
{
    String OwnerName;

    public CgetOwner()
    {
    }

    public CgetOwner(String ownerName)
    {
        OwnerName = ownerName;
    }

    public String getOwnerName() {
        return OwnerName;
    }

    public void setOwnerName(String ownerName) {
        OwnerName = ownerName;
    }
}
