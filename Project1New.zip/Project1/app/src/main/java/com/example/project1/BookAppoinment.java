package com.example.project1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BookAppoinment extends AppCompatActivity
{
    EditText date;
    Spinner time;
    Button nextbtn;
    String getDate,getTime,date1;
    Customer customer,customer1;
    DatabaseReference refee,reference,ref;
    String MobNoo;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appoinment);

        SharedPreferences sharedPreferences=getSharedPreferences("UserLogin",MODE_PRIVATE);
        final String Customermob=sharedPreferences.getString("MobNo",null);
        MobNoo="91"+Customermob;

        customer=new Customer();
        customer1=new Customer();



        date=(EditText)findViewById(R.id.getDate);
        time=(Spinner)findViewById(R.id.getTime);
        nextbtn=(Button)findViewById(R.id.BookAppoinmentNext);

        final Calendar calendar = Calendar.getInstance();
        final int year=calendar.get(calendar.YEAR);
        final int month=calendar.get(calendar.MONTH);
        final int day=calendar.get(calendar.DAY_OF_MONTH);

        Intent intent=getIntent();
        final String shopID=intent.getStringExtra("shopID");

        final Calendar c = Calendar.getInstance();
        final SimpleDateFormat df = new SimpleDateFormat("yyyy,MM,dd");
        final String formattedDate = df.format(c.getTime());

        date.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

               DatePickerDialog datePickerDialog=new DatePickerDialog(BookAppoinment.this, new DatePickerDialog.OnDateSetListener() {
                    @Override

                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth)
                    {
                        month=month+1;
                        String smonth=Integer.toString(month);
                        String sday=Integer.toString(dayOfMonth);
                        if (sday.length()==1)
                        {
                            sday="0"+sday;
                        }
                        if (smonth.length()==1)
                        {
                            smonth="0"+smonth;
                        }
                        date1=year+","+smonth+","+sday;
                        date.setText(date1);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        nextbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                getDate=date.getText().toString();
                getTime=time.getSelectedItem().toString();

                if (getDate.isEmpty())
                {
                    Toast.makeText(BookAppoinment.this, "Chose a date", Toast.LENGTH_SHORT).show();              }
                else
                {
                    if (formattedDate.compareTo(date1)>0)
                    {
                        Toast.makeText(BookAppoinment.this, "Chosen date is not currect", Toast.LENGTH_LONG).show();
                    }
                    else
                        {

                            refee=FirebaseDatabase.getInstance().getReference().child("Customer");
                            Query query=refee.orderByChild("mobileNum").equalTo(MobNoo);
                            query.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot ds:dataSnapshot.getChildren())
                                    {
                                        if (dataSnapshot.exists())
                                        {
                                            customer1=ds.getValue(Customer.class);
                                            if (MobNoo.equals(customer1.mobileNum))
                                            {
                                                customer=customer1;
                                                Toast.makeText(BookAppoinment.this, "xxxxxxxxxx  ."+customer1.mobileNum, Toast.LENGTH_LONG).show();
                                                Toast.makeText(BookAppoinment.this, MobNoo, Toast.LENGTH_SHORT).show();

                                            }
                                        }
                                        else
                                        {
                                            Toast.makeText(BookAppoinment.this, "snapshot doesnot exist", Toast.LENGTH_SHORT).show();
                                        }

                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                            reference = FirebaseDatabase.getInstance().getReference().child("ShopOwners").child(shopID).child("Booking").child(getDate);
                            reference.addValueEventListener(new ValueEventListener()
                            {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                                {
                                    if (dataSnapshot.exists())
                                    {
                                        reference.child(getTime).addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                                            {
                                                if (dataSnapshot.exists())
                                                {
                                                   //Toast.makeText(BookAppoinment.this, "The Time Has already Booked", Toast.LENGTH_SHORT).show();
                                                }
                                                else
                                                {
                                                    reference.child(getTime).setValue(customer).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid)
                                                        {
                                                            //Toast.makeText(BookAppoinment.this, "booking Placed", Toast.LENGTH_SHORT).show();
                                                            Intent intent1=new Intent(getApplicationContext(),Bookin_status_show.class);
                                                            startActivity(intent1);
                                                        }
                                                    });

                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {

                                            }
                                        });
                                    }
                                    else
                                    {
                                        ref=FirebaseDatabase.getInstance().getReference().child("ShopOwners").child(shopID).child("Booking").child(getDate);
                                        ref.child(getTime).setValue(customer).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid)
                                            {
                                                //Toast.makeText(BookAppoinment.this, "Your request has been placed sucessfully", Toast.LENGTH_SHORT).show();
                                                Intent intent1=new Intent(getApplicationContext(),Bookin_status_show.class);
                                                startActivity(intent1);
                                            }
                                        });
                                    }
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError)
                                {
                                    Toast.makeText(BookAppoinment.this, "Database Error...!", Toast.LENGTH_SHORT).show();
                                }
                            });

                        }
                }
            }
        });
    }
}
