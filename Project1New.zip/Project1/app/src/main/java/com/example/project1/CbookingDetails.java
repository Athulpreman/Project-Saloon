package com.example.project1;

public class CbookingDetails
{
    String Time,UserMob,UserName;
    Boolean Status;
}

